// Created Using Easy HTML v1.2.1
// https://play.google.com/store/apps/details?id=ak.andro.easyhtml

function cambio() {
	
	document.getElementById("cuad").css("background-color", "yellow");
	document.getElementById("cuad").style.color = "green";
   }