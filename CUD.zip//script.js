// Created Using Easy HTML v1.2.1
// https://play.google.com/store/apps/details?id=ak.andro.easyhtml

 function add_li()
        {
            var nuevoLi=document.getElementById("nuevo_li").value;
            if(nuevoLi.length>0)
            {
                if(find_li(nuevoLi))
                {
                    var li=document.createElement('li');
                  document.getElementById("listaDesordenada").appendChild(li);
                    li.id=nuevoLi;
                  
                    li.innerHTML='<button type="button" onclick="eliminar(this)">Borrar</button>'+nuevoLi;
                    
                }
            }
            return false;
        }
 
        /**
         * Funcion que busca si existe ya el <li> dentrol del <ul>
         * Devuelve true si no existe.
         */
        function find_li(contenido)
        {
            var el = document.getElementById("listaDesordenada").getElementsByTagName("li");
            for (var i=0; i<el.length; i++)
            {
                if(el[i].innerHTML==contenido)
                    return false;
            }
            return true;
        }
 
        /**
         * Funcion para eliminar los elementos
         * Tiene que recibir el elemento pulsado
         */
        function eliminar(elemento)
        {
            var id=elemento.parentNode.getAttribute("id");
            node=document.getElementById(id);
            node.parentNode.removeChild(node);
        }