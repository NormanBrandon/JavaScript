// Created Using Easy HTML v1.2.1
// https://play.google.com/store/apps/details?id=ak.andro.easyhtml


	function lista(){
		alert("Ingresar elementos en la lista")
		var x = prompt("cuantos elementos quieres en la lista?")

		var list = document.getElementById('milista');
		
		for(var i = 0; i<x ;i++){
			var z = prompt("ingresa elemento "+(i+1));
			var entry = document.createElement('li');
			entry.appendChild(document.createTextNode(z));
			list.appendChild(entry);
		}
	}

