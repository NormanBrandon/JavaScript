// Created Using Easy HTML v1.2.1
// https://play.google.com/store/apps/details?id=ak.andro.easyhtml

function jugar(){
        var n=document.getElementById("num1");
        var aleatorio = Math.round(Math.random()*2);
        var cpu ="";
  if(aleatorio==0)
   { cpu="piedra";}
  else if(aleatorio==1)
    {cpu="papel";}
    else 
     {cpu="tijeras";}
  
  if(n.value=="tijeras" || n.value=="piedra"||n.value=="papel")
  {
  alert("Su entrada fue : "+n.value);
  alert("CPU dice: "+cpu);
  if(n.value==cpu){
    alert("Empate");}
    else if (n.value=="tijeras" && cpu=="piedra")
     { alert("cpu gana");}
    else if (n.value=="papel"&& cpu="tijeras")
     { alert("cpu gana");}
    else if (n.value=="piedra"&& cpu=="papel")
     { alert("cpu gana");}
   else
      {alert("tu ganas");}
    
  
  
  
  }
  
  else{
    alert("entrada invalida");}
  
      }